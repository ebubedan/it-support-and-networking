# Wireless Access Point Troubleshooting

## Overview

I participated in troubleshooting a wireless access point serving a guest-room area. The activity was carried out with a more experienced colleague.

## My involvement

- Worked alongside a colleague to investigate the access-point connectivity issue.
- Participated in the troubleshooting process.
- Observed how a network connectivity complaint is investigated in a live environment.

## What I learned

- A wireless access point allows wireless devices to connect to a wired network.
- Connectivity problems can involve the access point, its cable or switch connection, power, configuration, or upstream network.
- Troubleshooting should be systematic rather than based on assumptions.

## Further learning

I plan to practise checking link status, power, cabling, client connectivity and access-point configuration in a safe lab environment.

## Skills

`Wireless Networking` `Troubleshooting` `Technical Support`

> Portfolio note: Add the exact fault, diagnostic commands and verified resolution only if you can confirm them. Do not publish internal network details.
